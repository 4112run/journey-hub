import '/flutter_flow/flutter_flow_util.dart';
import 'quick_link_widget.dart' show QuickLinkWidget;
import 'package:flutter/material.dart';

class QuickLinkModel extends FlutterFlowModel<QuickLinkWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
