package com.mycompany.geminiapidevelopercopetition

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
